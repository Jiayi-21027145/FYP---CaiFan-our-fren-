using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP5.Views.Summary
{
    public class _ChartPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

﻿namespace FYP5.Models
{
    public class Summary
    {
        public string? UserId { get; set; }
        public int TotalCalories { get; set; }
        public int TotalCount { get; set; }
        public int TotalPic{ get; set; }
    }
}

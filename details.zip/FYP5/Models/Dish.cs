﻿namespace FYP5.Models
{
    public class Dish
    {
        public int FoodId { get; set; }
        public string? Name { get; set; }
        public int HighestNV { get; set; }
        public int LowestNV { get; set; }
    }
}

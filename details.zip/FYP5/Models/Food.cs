﻿namespace FYP5.Models
{
    public class Food
    {
        public string? UserId { get; set; }
        public DateTime Date { get; set; }
        public string? FoodOne { get; set; }
        public string? FoodTwo { get; set; }
        public string? FoodThree { get; set; }
        public string? FoodFour { get; set; }
        public string? FoodFive { get; set; }
        public string? FoodSix { get; set; }

    }
}
